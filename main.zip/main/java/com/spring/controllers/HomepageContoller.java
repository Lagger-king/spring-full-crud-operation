package com.spring.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.Dao.UserDao;
import com.spring.model.User;

@Controller
public class HomepageContoller {

	@Autowired
	UserDao userDao;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String HomePage(ModelMap map) {

		map.addAttribute("msg", "Welcome to home page");

		return "HomePage";
	}

	@RequestMapping(value = "/getSignUpPage", method = RequestMethod.GET)
	public String registerUser(ModelMap map) {

		map.addAttribute("userObj", new User());
		map.addAttribute("registration", "Successfully Registered");
		return "Registration";
	}

	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public String registerUserDetail(@ModelAttribute User userObj, ModelMap map) {
		userDao.registerUser(userObj);
		map.addAttribute("registration", "Successfully Registered");
		return "HomePage";
	}

	@RequestMapping(value = "/getLoginForm", method = RequestMethod.GET)
	public String signIn()

	{
		return "Login";

	}
	
	
	@Autowired
	HttpSession session;
	
	@RequestMapping(value = "/Loginform", method = RequestMethod.POST)
	public String SignInfrom(@RequestParam int userId, @RequestParam String password) {
		User obj = userDao.validateUser(userId, password);
		session.setAttribute("uobj1",obj);
		if (obj != null) {
			
			
			if (obj.getRole().equals("admin"))

			{
				return "adminLogin";
				
			}
			else if (obj.getRole().equals("customer")) {
				return "userLogin";
			}
			}

			
		return "Login";

		}

	@RequestMapping(value="/getAllprofile",method=RequestMethod.GET)
	public ModelAndView getAllUserProfile()
	{
		List<User> users=userDao.getAllUsers();
		ModelAndView mv=new ModelAndView("ViewAllProfile");
		mv.addObject("UserObject",users);
		
		return mv;
		
	}
	}
